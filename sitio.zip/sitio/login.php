<div class="text-center mt-5">
  <h1>Ingreso al sistema</h1>
  <p class="lead">
  <form action="index.php"  method="post" >
  <input type="text"  name="user"
   placeholder="User name"
   class="form-control">
   <input type="password"  name="pwd"
   placeholder="Passwors user"
   class="form-control">
  </form>
  </p>
  
 </div>